from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 5
_modified_time = 1283139643.59007
_template_filename='/var/www/SimpleSite/simplesite/templates/derived/page/new.html'
_template_uri='/derived/page/new.html'
_template_cache=cache.Cache(__name__, _modified_time)
_source_encoding='utf-8'
from webhelpers.html import escape
_exports = ['heading']


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, '/base/index.html', _template_uri)
def render_body(context,**pageargs):
    context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        h = context.get('h', UNDEFINED)
        __M_writer = context.writer()
        # SOURCE LINE 1
        __M_writer(u'\n\n')
        # SOURCE LINE 5
        __M_writer(u'\n\n')
        # SOURCE LINE 7
        __M_writer(escape(h.form(h.url(controller='page', action='create'), method='post')))
        __M_writer(u'\nFirst Name: \t')
        # SOURCE LINE 8
        __M_writer(escape(h.text('firstname')))
        __M_writer(u'\nLast Name:\t\t')
        # SOURCE LINE 9
        __M_writer(escape(h.text('lastname')))
        __M_writer(u' \nNumber: \t\t')
        # SOURCE LINE 10
        __M_writer(escape(h.text('number')))
        __M_writer(u'\nFilename: \t')
        # SOURCE LINE 11
        __M_writer(escape(h.text('filename')))
        __M_writer(u'\n\t')
        # SOURCE LINE 12
        __M_writer(escape(h.submit('submit', 'Create Page')))
        __M_writer(u'\n')
        # SOURCE LINE 13
        __M_writer(escape(h.end_form()))
        __M_writer(u'\n\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


def render_heading(context):
    context.caller_stack._push_frame()
    try:
        __M_writer = context.writer()
        # SOURCE LINE 3
        __M_writer(u'\n\t<h1 class="main">Create a Whitelist Entry</h1>\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


