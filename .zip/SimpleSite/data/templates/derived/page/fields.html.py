from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 5
_modified_time = 1280102501.783674
_template_filename='/var/www/SimpleSite/simplesite/templates/derived/page/fields.html'
_template_uri='/derived/page/fields.html'
_template_cache=cache.Cache(__name__, _modified_time)
_source_encoding='utf-8'
from webhelpers.html import escape
_exports = []


def render_body(context,**pageargs):
    context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        c = context.get('c', UNDEFINED)
        __M_writer = context.writer()
        # SOURCE LINE 1
        __M_writer(escape(c.form.field(label="Heading",type='text',name='Heading')))
        __M_writer(u'\n')
        # SOURCE LINE 2
        __M_writer(escape(c.form.field(label="Title",type='text',required=True,name='title')))
        __M_writer(u'\n')
        # SOURCE LINE 3
        __M_writer(escape(c.form.field(label= "Content",type='text',required=True,name='content')))
        __M_writer(u'\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


