This file is for you to describe the SimpleSite application. Typically
you would include information such as the information below:

Installation and Setup
======================

Install ``SimpleSite`` using easy_install::

    easy_install SimpleSite

Make a config file as follows::

    paster make-config SimpleSite config.ini

Tweak the config file as appropriate and then setup the application::

    paster setup-app config.ini

Then you are ready to go.
